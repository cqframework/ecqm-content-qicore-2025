The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 11 - b247e1af-4d1a-42c1-be34-7c74987da0bd = ConditionPass Condition
Case # 10 - 2dabc75c-cce7-4337-a92f-bf0d60546b5a = BloodGlucosePass BloodGlucoseEffective
Case # 8 - 62f50a3d-3fd0-4e3c-a163-3bc6f35ce8da = IPOPPass InptEncDiabeticMedEncClassInpatientEncounter
Case # 7 - 081a12b5-6d27-4380-9085-d44680b7bb3b = IPOPPass InptEncDiabeticMedEncClassShortStay
Case # 6 - 0b97cf11-42c5-4f2d-b80d-be2f0e3d2501 = IPOPPass InptEncDiabeticMedEncClassInptNonAcute
Case # 5 - de3b49e7-ffd3-4f5a-aa3a-249aefd1f0d0 = IPOPPass InptEncStatusEnteredInErrorLocationEncClassInptAcute
Case # 4 - 7ce282c2-9138-457b-9ef5-3de129f81dac = IPOPPass InptEncStatusOnLeave
Case # 3 - 6e88eab1-b0a7-42b6-a257-253da0447fc5 = IPOPPass InptEncStatusTriaged
Case # 2 - 1e403fe4-88cd-4dbf-8942-e262ae91b2c4 = IPOPPass InptEncStatusInProgress
Case # 1 - 62cfb49d-d68f-4366-ada1-977e827ca7e2 = IPOPPass InptEncStatusFinished