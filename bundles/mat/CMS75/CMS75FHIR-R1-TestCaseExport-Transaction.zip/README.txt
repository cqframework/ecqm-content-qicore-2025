The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

f076026e-a9df-4c3c-acc9-8c3af6845543 = NUMPass DentalCariesCondEndsJan1OfMP
ebb4d1e8-32af-4811-adc5-f84a7318c5b8 = DENEXPass HospiceServicesEndOnJan1OfMP
e72e9b43-d488-41d1-835d-9222337639b2 = DENEXFail DischargeToHomeInpatient
d1b991a9-34a5-4926-8b52-694e5bc41bae = IPFail 20yrsWithOralEvalEncDec31B4MP
c17b4f9b-4821-4152-aac5-cafb99b3470c = IPPass 1yrWithOralEvalEncJan1OfMP
bed5f054-2f38-4b02-998f-e7e64012cfb9 = DENEXFail HospiceServicesEndOnJan1AfterMP
b532c8f5-b38a-4337-8661-7b744e271a9c = DENEXPass HospiceServicesEndOnDec31OfMP
a42cd354-1966-45d5-aec2-2d42225e6911 = DENEXPass HospiceEncOverlapsMP
a1d949ba-b8dd-453d-8565-f168e027b329 = NUMFail DentalCariesCondEndsDec31B4MP
303676f7-30b4-4324-8ab3-8d5ab7e92102 = DENEXPass HospiceObsValueIsYes
26549e84-fbf3-43dc-8971-2f3baaf508d7 = DENEXPass HospiceDiagnosisStartsDuringMP
326c7237-c7a4-4e1b-bd1d-ba518dc942dd = DENEXPass HospiceProcedureOverlapsMP
043f64b7-dd25-42ea-9785-0bdcbe64b27a = DENEXPass HospiceServiceRequestCompleted
8ed53f97-fe74-47f6-bf94-d3e85e70e1dd = IPFail 20yrsWithOralEvalEncJan1AfterMP
8b91c8d5-4fed-4be7-b930-ba922a502c05 = NUMPass DentalCariesCondStartsDec31OfMP
6ddffc8d-02e7-44ce-a766-e67ae088db62 = DENEXFail HospiceServicesEndOnDec31B4MP
3e98ff8c-6d30-4a34-aabe-579419dd834f = IPPass 20yrsWithOralEvalEncDec31OfMP
02b613cd-c4f0-431d-8799-2ed39b11785f = NUMFail DentalCariesCondEndsJan1AfterMP
1f4e0855-2a5a-4076-8086-10a14e61c298 = IPFail 11mo30daysOld
0af30a0b-0bdd-4868-976e-0eafa69c60db = IPFail 21yrsWithOralEvalEncJan1OfMP