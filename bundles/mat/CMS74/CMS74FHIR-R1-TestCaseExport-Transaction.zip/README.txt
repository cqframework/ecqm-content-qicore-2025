The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

3d962304-b248-4e8b-9e42-b382a5b4754c = NUMFail FlourideAppProcsDec31B4MP
fe5f3172-5263-4498-b1ba-0d62de7455ef = DENEXPass HospiceDiagnosisStartsDuringMP
88696ecd-d24d-44f6-a0c7-a0fc78f6c556 = IPFail 20yrsWithOralEvalEncJan1AfterMP
8980b94a-4c69-4ca2-8546-c5a586cb6aba = IPPass 1yrWithOralEvalEncJan1OfMP
499fd8d2-0a68-4d27-a194-c61aae97e492 = DENEXPass HospiceProcedureOverlapsMP
96c38952-91cc-468c-b16b-32386bb312ec = DENEXPass HospiceServiceRequestCompleted
05b311bd-7a73-4949-8dc3-35c0037503ad = IPFail 20yrsWithOralEvalEncDec31B4MP
4c5a69b7-007e-41b8-9607-fd0b97ef271d = DENEXFail HospiceServicesEndOnJan1AfterMP
1f9df3c7-191e-4260-9115-dc10bfcdbee3 = DENEXFail DischargeToHomeInpatient
ed7ad3f4-507a-4980-aefa-7d6a8baafaa2 = IPPass 20yrsWithOralEvalEncDec31OfMP
e428789b-b5ca-4d15-9a7b-4f527303fc9e = NUMFail FlourideAppProcsJan1AfterMP
70208367-16df-46d6-b49c-c1e31b7e1d5f = DENEXPass HospiceEncOverlapsMP
11400976-3c1b-42ec-8d60-f29252f553b6 = IPFail 11mo30daysWithOralEvalEncJan1OfMP
222141c3-c8c7-48b6-a354-d816b6bbaa41 = IPFail 21yrsWithOralEvalEncJan1OfMP
890dbdad-7466-494d-966b-a20515508db5 = DENEXPass HospiceObsValueIsYes
848d64c5-3228-455d-b168-2172a0d93a3a = DENEXFail HospiceServicesEndOnDec31B4MP
675a057f-26ea-4e4f-8b94-dc3c05763f39 = Strat2Pass 6yrsWithOralEvalEncJan1OfMP
31bee4bc-9ca4-4d84-9f1a-a6a6d2d3fac0 = DENEXPass HospiceServicesEndOnDec31OfMP
4fc1e663-46e6-4159-853d-b2dbb146b2ac = DENEXPass HospiceServicesEndOnJan1OfMP
04d34ff1-968e-4ad9-9c61-250ddd6a5828 = NUMPass FlourideAppProcsJan1AndDec31OfMP