The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

b4cd38ff-6828-49bc-b8e6-d4a24b9624b1 = IPPass VirtualEncounter
dc4c8b59-2a44-4a74-9983-48baabe5679f = IPPass TelephoneVisit
778e804e-7356-400f-bc36-8d202d775509 = IPPass PsychVisitPsychotherapy
ce747de2-3f8f-4ad8-8370-3ed53b990094 = IPPass PsychVisitDxEval
0b61ffb2-9d2d-4eb4-a208-f34f74824543 = IPPass NursingFacilityVisit
a3733b4f-0049-45cf-8b30-3e56ec3d5301 = IPPass HHSVisit
3207b0d6-43cb-4dd7-a71f-db8ad4b9e07a = IPPass AnnualWellnessVisit
40ed567d-9ecf-4bf8-b552-be9b87a6834d = IPPass PreventiveCareInitialVisit18Up
bdbc73af-00ed-4eca-b5a4-dfaab4fc2c8c = IPPass PreventiveCareEstablishedVisit18Up
62ea0c3d-46da-48a1-87dd-d1927ed2df75 = DENEXPass HospiceServiceRequestDuringMP