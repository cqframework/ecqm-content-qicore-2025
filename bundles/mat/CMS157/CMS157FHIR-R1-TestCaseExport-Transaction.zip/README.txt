The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

fe6ef07d-bff1-4e0e-9bf4-b0424a1d0ab4 = IPPPassPop1 ChemoSameDayofEncAnd30DaysB4Enc
4bf7c1f5-8c25-4cd9-9ca8-d67e9f1283cb = IPPFailPop1 OneChemoAdministered
be20e6d8-f2f2-49d9-abc1-39e93ba36a1c = IPPFailPop1 EncAfterMP
91ebcd41-a1a5-45e0-95fd-e2a2799f4459 = IPPFailPop1 EncPriorMP
f0f73fe9-f8ae-4994-911f-1745e5efbce3 = IPPFailPop1 CancerDxEndsPriorEnc
ea08cba3-e556-496e-8aab-3b1e6f58fda0 = IPPFailPop1 NoChemoPriorEnc
6c1a8557-73be-4026-9ec6-f0699bfcbfda = IPPFailPop1 CancerDxStartsAfterEncAndChemo
ba6d787f-d15f-4e22-8ee4-30c12d53aa37 = IPPFailPop1And2 NoEncChemoOrRadTx
bbdccaa6-f3a0-426d-8e77-eff43095cfc9 = NUMERFailPop2 PainAssessPriorRadTx
18a871b4-b7d2-4fca-bd04-155b44965f4e = NUMERFailPop2 PainAssessDuringOVEncNotRadTx