The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

946c9d68-dc7a-449a-a113-d76a735e3403 = IPPass PreventiveCareEstablishedVisit
d70985bf-27fc-4f62-b44f-fecfac881b6a = IPPass PreventiveCareEstablishedVisit18Up
0b0bcb31-89d5-4246-8b55-fae200385eab = IPPass UnlistedPreventativeMedSer
35113f5b-7982-4c28-9103-32bbc1d6bfde = IPPass PreventiveCareInitialVisit18Up
9c9abe56-16c0-4ba0-b2fa-146256ec0886 = IPPass PreventiveCareInitialVisit
ee64c224-892c-48e9-931a-a00301b5b0e6 = IPPass PreventiveCareIndividualCounseling
8120cffc-faec-4295-93f9-a30275075ee5 = IPPass PreventiveCareGroupCounseling
f2d9aa30-e8ae-4b9b-81b8-3a64c5c939ca = IPPass OutpatientConsultation
51cf228c-64f1-465b-9eb0-58d986a27cb7 = IPPass VirtualEncounter
d2f3c4a0-b4bb-4407-9a78-e76775ff5bd1 = IPPass OfficeVisit