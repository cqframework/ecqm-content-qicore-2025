The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

a9545a75-1461-4bf0-a105-d60ba84772a5 = NUMERPass TwoScans
e80a2dd2-d2e8-4888-86e6-8bf2b6516e79 = NUMERPass HighNoise
d735a266-abd3-4392-b9f4-7eb953ea9529 = DENOMPass AllScans
8852a08d-a245-4549-a661-6afdf2c79d2c = DENOMFail NoUnits
93a345b0-259a-4c1d-8c85-280a6e78a006 = DENOMFail MissingResults
87e15976-6935-4de9-b594-6169b4dbda7a = NUMERPass HighDose
15f7e535-9af3-4fdf-b3b3-8fa6b9d6ca76 = IPPPass Age18
405bb76e-a162-49ad-8b52-9f6f745efb64 = IPPFail Under18
1d5593d0-f513-46f6-8c2d-538685a61185 = IPPFail ScanOutsideMP
03da9890-9eda-480c-99c8-d04a4e2f4204 = DENOMPass AbdopelrtGood