The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

bd9b9e02-ce12-43cb-af1c-25298c891e62 = DENEXPass HospiceServicesEndOnJan1OfMP
259f8551-1cea-44f5-ae9e-e3f083d9f48f = DENEXPass HospiceServicesEndOnDec31OfMP
1e0720b0-0782-4455-a355-8c1ecec3c653 = DENEXPass HospiceServiceRequestDuringMP
598662b8-30c9-4f9b-a2d1-d91bea113d77 = DENEXPass HospiceProcedureStartsDuringMP
4a9211fc-d757-47ae-8bc0-0803c43a6728 = DENEXPass HospiceObsValueIsYes
4304f97a-e2bb-4cda-93fa-ab510a136403 = DENEXPass HospiceEncounterOverlapsMP
a0c68789-2a1b-4bc4-b6a4-d8f6b154d8ac = DENEXPass HospiceDischargeToHomeDuringMP
dbb639f6-f7b7-41c8-bc30-84e5574c08cd = DENEXPass HospiceDiagnosisOverlapsMP
dfabce9a-f0fe-4095-a948-074d3aa8ccc7 = DENEXFail HospiceServicesEndOnJan1AfterMP
362bc370-9fa5-4806-9cd3-378c484fa873 = DENEXFail HospiceServicesEndOnDec31B4MP