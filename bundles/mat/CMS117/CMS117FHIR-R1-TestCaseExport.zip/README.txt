The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

92ed2664-a594-4cac-9001-3044b14a02f7 = DENEXPass HospiceDischargeToHomeDuringMP
15067a1f-bfa9-4dbc-b622-b2da823bea79 = NUMERPass AllVaccinesAsProcedures2Hib4LAIVRV3
a5ca4525-88bc-4b67-b880-ca1cf54daa88 = NUMERPass AllAnaphylaxisOrConditions
1e7dc519-5d75-4c07-b23f-ae9421a12943 = NUMERPass AllVacccinesWithProcedures
6b9e1f1b-90db-42f2-8591-f1a1858ca27a = NUMERFail TwoDTapSameDay
aeb0266c-a8ec-4262-a4bc-6bc343a85230 = DENEXPass HospiceServiceRequestDuringMP
104ee6b1-c36f-420c-bedd-0a2064f748d8 = DENEXPass HospiceProcedureStartsDuringMP
dd1e534c-aa60-4ff3-a955-109f034b408f = DENEXPass HospiceDiagnosisOverlapsMP
b5f9f533-30c2-4fbe-b06e-3f8dccc8792c = DENEXPass HospiceObsValueIsYes
9e57c539-0442-415a-a187-87adc7acdd8a = DENEXPass HospiceDischargeToFacilityDuringMP