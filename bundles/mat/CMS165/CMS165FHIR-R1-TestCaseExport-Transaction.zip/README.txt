The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

45e01fed-56bb-483d-a860-af3d566bda11 = DENEXPass DementiaMedicationRequestAsReference
4b31dc2b-7867-4766-8a8c-e1971d1e570a = DENEXPass PalliativeCareEncounterDuringMP
78fc0433-a72a-45a3-b2c4-995e614674cb = DENEXPass ESRDEncDuringMP
546de5d8-f614-41c7-938f-671d14e4f540 = IPPass HomeHealthcareService
7de4b027-eb4c-4a2e-958f-e6b7a3eb6309 = DENEXPass KidneyTransplantProcedureDuringMP
0b9cb569-149a-4b47-a535-66b59a77bceb = DENEXPass ChronicKidneyDiseaseStage5DuringMP
1905549a-1783-4195-95b9-b0879cb81d96 = DENEXPass DementiaStartsDuringMP
4d50f3eb-f56f-4f13-8fcf-4d26e05b9a6a = IPPass HypertensionDuringFirst6Months
b378c30b-ebc2-4378-9a75-8a97711cac81 = DENEXFail LastHousingStatusNotNursingHome
0e867903-400d-4d71-a7fd-dc9b96d94a17 = DENEXPass HospiceProcedureStartsDuringMP