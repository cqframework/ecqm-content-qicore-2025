The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

25938d1a-7785-4453-9574-01ccb82cb3e8 = IPPDENOMFail EncOverlapsMP
4ce081ec-bc42-44c6-bfbb-ad853903e3d1 = DENEXCEPFail MedNoDocStatusNotDone
6bffc7ce-d4ac-42e2-9fd0-48b58e45d502 = IPPDENOMFail EncBeforeMP
0111c1a9-1590-40d6-8023-0e3bd45d493e = IPPDENOMFail EncAfterMP
37daa71d-a2a5-4807-8ee1-93417424ffee = NUMERPass EncEndsLastDayMPAt2359Doc1stMinEnc
ebea0fbe-8ab4-43a2-8bfa-5117bb8d56a9 = NUMERFail MedsNoDocAfterEncPeriod
b6b76d56-4dd6-4394-98e3-97dbd3236675 = NUMERPass EncEndsLastDayMPAt2359DocLastMinEnc
8b704351-4052-4207-8f69-e259ca15bf62 = IPPDENOMFail EncStatusNotFinished
12626e98-67c8-4f3d-bac5-dbb5d57f58c8 = NUMERPass EncFinishedProcedureCompleted
6f04cfd6-8557-4eff-84cb-9d3ed094dc4b = NUMERFail MedsNoDocStatusNotValid
9ada2736-229a-40d4-b026-2bdec85c6d02 = NUMERPass Enc1stDayMPAt0000
d1f4cbfc-1f86-408b-a65d-50250a4dd148 = NUMERFail MedsNoDocBeforeEncPeriod
3d42d9f8-0381-4562-94b7-314fcd27fae5 = DENEXCEPFail MedNoDocStatusRejectedNoReason
60ad5deb-5c36-4ba3-bdee-9390f7ffdf6e = IPPDENOMPass EncMPStatusFinishedDuringMP
f2e2e1c0-9e35-4592-9579-72a236cb2f56 = DENEXCEPPass MedNoDocStatusRejectedWithReasonCode
f254d721-854c-4b26-9d14-e6052c341501 = IPPDENOMFail NoQualifyingEnc
db7bf97d-edaf-41c9-bf02-81a3f31db686 = IPPDENOMFail Encounter1MinBeforeMPBegins
33c3042b-b935-456f-b22b-f3f55cf56cdc = IPPDENOMPass EncMPStatusFinished
14943c8d-1551-4449-b244-f3381a6f4e28 = IPPDENOMFail Encounter1MinAfterMPEnds